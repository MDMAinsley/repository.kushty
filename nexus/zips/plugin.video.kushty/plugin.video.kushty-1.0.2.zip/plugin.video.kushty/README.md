# Kushty Video Add-on

The only add-on you'll need again

Head back to the repo to install the Skin that works sweet with this plugin

Any issues, head to the GitHub and i'll get on it
Impatient? Know how to fix something? Push to the repo???